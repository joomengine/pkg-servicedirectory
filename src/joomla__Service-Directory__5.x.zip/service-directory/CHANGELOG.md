# v5.0.1

- Add the ticket view to the Service Directory for managing Company tickets.
- Add a Ticket tab to the Listing site view where a user can view all their Tickets.
- Add a support tab to Company that links Companies to the Ticket system.
- Fix Security breach in the edit and create of Companies and Tickets.