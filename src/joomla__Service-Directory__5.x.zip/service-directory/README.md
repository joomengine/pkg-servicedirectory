# Service Directory (5.0.x)

The Service Directory component is a powerful Joomla solution for creating and managing a public or private directory of people who offer services. Each listing can include essential contact details, a clear description of the services provided, and other relevant business information. The component also supports showcasing portfolios or previous work, allowing visitors to learn more about each provider's experience and capabilities.

Designed for flexibility and ease of use, Service Directory helps you organize and present service providers in an accessible, structured, and visually appealing way; perfect for communities, organizations, or businesses looking to connect users with the right services.

# Build Details

+ *Company*: [Vast Development Method](https://github.com/joomengine/Joomla-Service-Directory)
+ *Author*: [Lemuel van der Merwe](mailto:joomla@vdm.io)
+ *Name*: [Service Directory](https://github.com/joomengine/Joomla-Service-Directory)
+ *First Build*: 4th October, 2025
+ *Last Build*: 4th December, 2025
+ *Version*: 5.0.x
+ *Copyright*: Copyright (C) 2015 Vast Development Method. All rights reserved.
+ *License*: GNU General Public License version 2 or later; see LICENSE.txt

## Build Time

**893 Hours** or **111 Eight Hour Days**  (actual time the author saved - 
due to [Automated Component Builder](https://www.joomlacomponentbuilder.com))

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> never making one mistake or taking any coffee break.)

+ *Line count*: **337947**
+ *File count*: **1180**
+ *Folder count*: **226**

**581 Hours** or **73 Eight Hour Days** (the actual time the author spent)

> (with the following break down:
> **debugging @223hours** = codingtime / 4;
> **planning @125hours** = codingtime / 7;
> **mapping @89hours** = codingtime / 10;
> **office @142hours** = codingtime / 6;)

**1474 Hours** or **184 Eight Hour Days**
(a total of the realistic time frame for this project)

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> with the normal everyday realities at the office, that includes the component planning, mapping & debugging.)

Project duration: **36.8 weeks** or **7.6 months**

> This **component** was build with a Joomla [Automated Component Builder](https://www.joomlacomponentbuilder.com).
> Developed by [Llewellyn van der Merwe](mailto:joomla@vdm.io)

## Donations

 If you want to support this project, please consider donating:
 * Open Collective: [Joomla-Component-Builder](https://opencollective.com/Joomla-Component-Builder)