# Service Directory (5.0.x)

The Service Directory component is a powerful Joomla solution for creating and managing a public or private directory of people who offer services. Each listing can include essential contact details, a clear description of the services provided, and other relevant business information. The component also supports showcasing portfolios or previous work, allowing visitors to learn more about each provider's experience and capabilities.

Designed for flexibility and ease of use, Service Directory helps you organize and present service providers in an accessible, structured, and visually appealing way; perfect for communities, organizations, or businesses looking to connect users with the right services.

# Build Details

+ *Company*: [Vast Development Method](https://github.com/joomengine/Joomla-Service-Directory)
+ *Author*: [Lemuel van der Merwe](mailto:joomla@vdm.io)
+ *Name*: [Service Directory](https://github.com/joomengine/Joomla-Service-Directory)
+ *First Build*: 4th October, 2025
+ *Last Build*: 26th October, 2025
+ *Version*: 5.0.x
+ *Copyright*: Copyright (C) 2015 Vast Development Method. All rights reserved.
+ *License*: GNU General Public License version 2 or later; see LICENSE.txt

## Build Time

**925 Hours** or **116 Eight Hour Days**  (actual time the author saved - 
due to [Automated Component Builder](https://www.joomlacomponentbuilder.com))

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> never making one mistake or taking any coffee break.)

+ *Line count*: **332440**
+ *File count*: **1137**
+ *Folder count*: **220**

**611 Hours** or **76 Eight Hour Days** (the actual time the author spent)

> (with the following break down:
> **debugging @231hours** = codingtime / 4;
> **planning @132hours** = codingtime / 7;
> **mapping @93hours** = codingtime / 10;
> **office @154hours** = codingtime / 6;)

**1536 Hours** or **192 Eight Hour Days**
(a total of the realistic time frame for this project)

> (if creating a folder and file took **5 seconds** and writing one line of code took **10 seconds**,
> with the normal everyday realities at the office, that includes the component planning, mapping & debugging.)

Project duration: **38.4 weeks** or **8 months**

> This **component** was build with a Joomla [Automated Component Builder](https://www.joomlacomponentbuilder.com).
> Developed by [Llewellyn van der Merwe](mailto:joomla@vdm.io)

## Donations

 If you want to support this project, please consider donating:
 * Open Collective: [Joomla-Component-Builder](https://opencollective.com/Joomla-Component-Builder)