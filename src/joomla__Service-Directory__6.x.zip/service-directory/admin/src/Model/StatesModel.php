<?php
/**
 * @package    Service Directory
 *
 * @created    15th October, 2025
 * @author     Lemuel van der Merwe <https://github.com/joomengine/Joomla-Service-Directory>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 * A professional directory component for listing and showcasing service providers.
 */
namespace JoomService\Component\Servicedirectory\Administrator\Model;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\User\User;
use Joomla\Utilities\ArrayHelper;
use Joomla\Input\Input;
use JoomService\Component\Servicedirectory\Administrator\Helper\ServicedirectoryHelper;
use Joomla\CMS\Helper\TagsHelper;
use JoomService\Joomla\Utilities\ArrayHelper as UtilitiesArrayHelper;
use JoomService\Joomla\Utilities\ObjectHelper;
use JoomService\Joomla\Utilities\StringHelper;

// No direct access to this file
\defined('_JEXEC') or die;

/**
 * States List Model
 *
 * @since  1.6
 */
class StatesModel extends ListModel
{
	/**
	 * The application object.
	 *
	 * @var   CMSApplicationInterface  The application instance.
	 * @since 3.2.0
	 */
	protected CMSApplicationInterface $app;

	/**
	 * The styles array.
	 *
	 * @var    array
	 * @since  4.3
	 */
	protected array $styles = [
		'administrator/components/com_servicedirectory/assets/css/admin.css',
		'administrator/components/com_servicedirectory/assets/css/states.css'
 	];

	/**
	 * The scripts array.
	 *
	 * @var    array
	 * @since  4.3
	 */
	protected array $scripts = [
		'administrator/components/com_servicedirectory/assets/js/admin.js'
 	];

	/**
	 * Constructor
	 *
	 * @param   array                 $config   An array of configuration options (name, state, dbo, table_path, ignore_request).
	 * @param   ?MVCFactoryInterface  $factory  The factory.
	 *
	 * @since   1.6
	 * @throws  \Exception
	 */
	public function __construct($config = [], ?MVCFactoryInterface $factory = null)
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
				'a.id','id',
				'a.published','published',
				'a.access','access',
				'a.ordering','ordering',
				'a.created_by','created_by',
				'a.modified_by','modified_by',
				'g.name','country',
				'a.name','name',
				'a.type','type'
			);
		}

		parent::__construct($config, $factory);

		$this->app ??= Factory::getApplication();
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 * @since   1.7.0
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$app = $this->app;
		$input = $this->app->getInput();

		// Adjust the context to support modal layouts.
		if ($layout = $input->get('layout'))
		{
			$this->context .= '.' . $layout;
		}

		// Check if the form was submitted
		$formSubmited = $input->post->get('form_submited');

		$access = $this->getUserStateFromRequest($this->context . '.filter.access', 'filter_access', 0, 'int');
		if ($formSubmited)
		{
			$access = $input->post->get('access');
			$this->setState('filter.access', $access);
		}

		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);

		$created_by = $this->getUserStateFromRequest($this->context . '.filter.created_by', 'filter_created_by', '');
		$this->setState('filter.created_by', $created_by);

		$created = $this->getUserStateFromRequest($this->context . '.filter.created', 'filter_created');
		$this->setState('filter.created', $created);

		$sorting = $this->getUserStateFromRequest($this->context . '.filter.sorting', 'filter_sorting', 0, 'int');
		$this->setState('filter.sorting', $sorting);

		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$country = $this->getUserStateFromRequest($this->context . '.filter.country', 'filter_country');
		if ($formSubmited)
		{
			$country = $input->post->get('country');
			$this->setState('filter.country', $country);
		}

		$name = $this->getUserStateFromRequest($this->context . '.filter.name', 'filter_name');
		if ($formSubmited)
		{
			$name = $input->post->get('name');
			$this->setState('filter.name', $name);
		}

		$type = $this->getUserStateFromRequest($this->context . '.filter.type', 'filter_type');
		if ($formSubmited)
		{
			$type = $input->post->get('type');
			$this->setState('filter.type', $type);
		}

		// List state information.
		parent::populateState($ordering, $direction);
	}

	/**
	 * Method to get an array of data items.
	 *
	 * @return  mixed  An array of data items on success, false on failure.
	 * @since   1.6
	 */
	public function getItems()
	{
		// Check in items
		$this->checkInNow();

		// load parent items
		$items = parent::getItems();

		// Set values to display correctly.
		if (UtilitiesArrayHelper::check($items))
		{
			// Get the user object if not set.
			if (!isset($user) || !ObjectHelper::check($user))
			{
				$user = $this->getCurrentUser();
			}
			foreach ($items as $nr => &$item)
			{
				// Remove items the user can't access.
				$access = ($user->authorise('state.access', 'com_servicedirectory.state.' . (int) $item->id) && $user->authorise('state.access', 'com_servicedirectory'));
				if (!$access)
				{
					unset($items[$nr]);
					continue;
				}

			}
		}

		// set selection value to a translatable value
		if (UtilitiesArrayHelper::check($items))
		{
			foreach ($items as $nr => &$item)
			{
				// convert type
				$item->type = $this->selectionTranslation($item->type, 'type');
			}
		}


		// return items
		return $items;
	}

	/**
	 * Method to convert selection values to translatable string.
	 *
	 * @return  string   The translatable string.
	 */
	public function selectionTranslation($value,$name)
	{
		// Array of type language strings
		if ($name === 'type')
		{
			$typeArray = array(
				'department' => 'COM_SERVICEDIRECTORY_STATE_DEPARTMENT',
				'district' => 'COM_SERVICEDIRECTORY_STATE_DISTRICT',
				'region' => 'COM_SERVICEDIRECTORY_STATE_REGION',
				'province' => 'COM_SERVICEDIRECTORY_STATE_PROVINCE',
				'municipality' => 'COM_SERVICEDIRECTORY_STATE_MUNICIPALITY',
				'geographical region' => 'COM_SERVICEDIRECTORY_STATE_GEOGRAPHICAL_REGION',
				'popularate' => 'COM_SERVICEDIRECTORY_STATE_POPULARATE',
				'oblast' => 'COM_SERVICEDIRECTORY_STATE_OBLAST',
				'city' => 'COM_SERVICEDIRECTORY_STATE_CITY',
				'land' => 'COM_SERVICEDIRECTORY_STATE_LAND',
				'county' => 'COM_SERVICEDIRECTORY_STATE_COUNTY',
				'governorate' => 'COM_SERVICEDIRECTORY_STATE_GOVERNORATE',
				'administered area' => 'COM_SERVICEDIRECTORY_STATE_ADMINISTERED_AREA',
				'federal capital territory' => 'COM_SERVICEDIRECTORY_STATE_FEDERAL_CAPITAL_TERRITORY',
				'emirate' => 'COM_SERVICEDIRECTORY_STATE_EMIRATE',
				'special municipality' => 'COM_SERVICEDIRECTORY_STATE_SPECIAL_MUNICIPALITY',
				'state' => 'COM_SERVICEDIRECTORY_STATE_STATE',
				'metropolitan administration' => 'COM_SERVICEDIRECTORY_STATE_METROPOLITAN_ADMINISTRATION',
				'parish' => 'COM_SERVICEDIRECTORY_STATE_PARISH',
				'metropolitan city' => 'COM_SERVICEDIRECTORY_STATE_METROPOLITAN_CITY',
				'special self-governing province' => 'COM_SERVICEDIRECTORY_STATE_SPECIAL_SELFGOVERNING_PROVINCE',
				'special self-governing city' => 'COM_SERVICEDIRECTORY_STATE_SPECIAL_SELFGOVERNING_CITY',
				'dependency' => 'COM_SERVICEDIRECTORY_STATE_DEPENDENCY',
				'territory' => 'COM_SERVICEDIRECTORY_STATE_TERRITORY',
				'division' => 'COM_SERVICEDIRECTORY_STATE_DIVISION',
				'island council' => 'COM_SERVICEDIRECTORY_STATE_ISLAND_COUNCIL',
				'special city' => 'COM_SERVICEDIRECTORY_STATE_SPECIAL_CITY',
				'union territory' => 'COM_SERVICEDIRECTORY_STATE_UNION_TERRITORY',
				'autonomous territorial unit' => 'COM_SERVICEDIRECTORY_STATE_AUTONOMOUS_TERRITORIAL_UNIT',
				'overseas collectivity' => 'COM_SERVICEDIRECTORY_STATE_OVERSEAS_COLLECTIVITY',
				'metropolitan region' => 'COM_SERVICEDIRECTORY_STATE_METROPOLITAN_REGION',
				'metropolitan collectivity with special status' => 'COM_SERVICEDIRECTORY_STATE_METROPOLITAN_COLLECTIVITY_WITH_SPECIAL_STATUS',
				'overseas region' => 'COM_SERVICEDIRECTORY_STATE_OVERSEAS_REGION',
				'autonomous region' => 'COM_SERVICEDIRECTORY_STATE_AUTONOMOUS_REGION',
				'administrative region' => 'COM_SERVICEDIRECTORY_STATE_ADMINISTRATIVE_REGION',
				'capital district' => 'COM_SERVICEDIRECTORY_STATE_CAPITAL_DISTRICT',
				'prefecture' => 'COM_SERVICEDIRECTORY_STATE_PREFECTURE',
				'canton' => 'COM_SERVICEDIRECTORY_STATE_CANTON',
				'metropolitan department' => 'COM_SERVICEDIRECTORY_STATE_METROPOLITAN_DEPARTMENT',
				'overseas territory' => 'COM_SERVICEDIRECTORY_STATE_OVERSEAS_TERRITORY',
				'island' => 'COM_SERVICEDIRECTORY_STATE_ISLAND',
				'autonomous community' => 'COM_SERVICEDIRECTORY_STATE_AUTONOMOUS_COMMUNITY',
				'autonomous city' => 'COM_SERVICEDIRECTORY_STATE_AUTONOMOUS_CITY',
				'village' => 'COM_SERVICEDIRECTORY_STATE_VILLAGE',
				'sheadings' => 'COM_SERVICEDIRECTORY_STATE_SHEADINGS',
				'capital city' => 'COM_SERVICEDIRECTORY_STATE_CAPITAL_CITY',
				'district municipality' => 'COM_SERVICEDIRECTORY_STATE_DISTRICT_MUNICIPALITY'
			);
			// Now check if value is found in this array
			if (isset($typeArray[$value]) && StringHelper::check($typeArray[$value]))
			{
				return $typeArray[$value];
			}
		}
		return $value;
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return  string    An SQL query
	 * @since   1.6
	 */
	protected function getListQuery()
	{
		// Get the user object.
		$user = $this->getCurrentUser();
		// Create a new query object.
		$db = $this->getDatabase();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('a.*');

		// From the servicedirectory_item table
		$query->from($db->quoteName('#__servicedirectory_state', 'a'));

		// From the servicedirectory_country table.
		$query->select($db->quoteName(['g.name','g.id'],['country_name','country_id']));
		$query->join('LEFT', $db->quoteName('#__servicedirectory_country', 'g') . ' ON (' . $db->quoteName('a.country') . ' = ' . $db->quoteName('g.guid') . ')');

		// Filter by published state
		$published = $this->getState('filter.published');
		if (is_numeric($published))
		{
			$query->where('a.published = ' . (int) $published);
		}
		elseif ($published === '')
		{
			$query->where('(a.published = 0 OR a.published = 1)');
		}

		// Join over the asset groups.
		$query->select('ag.title AS access_level');
		$query->join('LEFT', '#__viewlevels AS ag ON ag.id = a.access');
		// Filter by access level.
		$_access = $this->getState('filter.access');
		if ($_access && is_numeric($_access))
		{
			$query->where('a.access = ' . (int) $_access);
		}
		elseif (UtilitiesArrayHelper::check($_access))
		{
			// Secure the array for the query
			$_access = ArrayHelper::toInteger($_access);
			// Filter by the Access Array.
			$query->where('a.access IN (' . implode(',', $_access) . ')');
		}
		// Implement View Level Access
		if (!$user->authorise('core.options', 'com_servicedirectory'))
		{
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query->where('a.access IN (' . $groups . ')');
		}
		// Filter by search.
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->quote('%' . $db->escape($search) . '%');
				$query->where('(a.name LIKE '.$search.' OR a.country LIKE '.$search.' OR g.name LIKE '.$search.' OR a.type LIKE '.$search.' OR a.wikidataid LIKE '.$search.' OR a.fips_code LIKE '.$search.' OR a.iso2 LIKE '.$search.' OR a.longitude LIKE '.$search.' OR a.latitude LIKE '.$search.')');
			}
		}

		// Filter by Country.
		$_country = $this->getState('filter.country');
		if (is_numeric($_country))
		{
			if (is_float($_country))
			{
				$query->where('a.country = ' . (float) $_country);
			}
			else
			{
				$query->where('a.country = ' . (int) $_country);
			}
		}
		elseif (StringHelper::check($_country))
		{
			$query->where('a.country = ' . $db->quote($db->escape($_country)));
		}

		// Add the list ordering clause.
		$orderCol = $this->getState('list.ordering', 'a.id');
		$orderDirn = $this->getState('list.direction', 'desc');
		if ($orderCol != '')
		{
			// Check that the order direction is valid encase we have a field called direction as part of filers.
			$orderDirn = (is_string($orderDirn) && in_array(strtolower($orderDirn), ['asc', 'desc'])) ? $orderDirn : 'desc';
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}

		return $query;
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * @return  string  A store id.
	 * @since   1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.id');
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.published');
		// Check if the value is an array
		$_access = $this->getState('filter.access');
		if (UtilitiesArrayHelper::check($_access))
		{
			$id .= ':' . implode(':', $_access);
		}
		// Check if this is only an number or string
		elseif (is_numeric($_access)
		 || StringHelper::check($_access))
		{
			$id .= ':' . $_access;
		}
		$id .= ':' . $this->getState('filter.ordering');
		$id .= ':' . $this->getState('filter.created_by');
		$id .= ':' . $this->getState('filter.modified_by');
		$id .= ':' . $this->getState('filter.country');
		$id .= ':' . $this->getState('filter.name');
		$id .= ':' . $this->getState('filter.type');

		return parent::getStoreId($id);
	}

	/**
	 * Method to get the styles that have to be included on the view
	 *
	 * @return  array    styles files
	 * @since   4.3
	 */
	public function getStyles(): array
	{
		return $this->styles;
	}

	/**
	 * Method to set the styles that have to be included on the view
	 *
	 * @return  void
	 * @since   4.3
	 */
	public function setStyles(string $path): void
	{
		$this->styles[] = $path;
	}

	/**
	 * Method to get the script that have to be included on the view
	 *
	 * @return  array    script files
	 * @since   4.3
	 */
	public function getScripts(): array
	{
		return $this->scripts;
	}

	/**
	 * Method to set the script that have to be included on the view
	 *
	 * @return  void
	 * @since   4.3
	 */
	public function setScript(string $path): void
	{
		$this->scripts[] = $path;
	}

	/**
	 * Build an SQL query to check in all items left checked out longer then a set time.
	 *
	 * @return void
	 * @throws \DateMalformedStringException
	 * @since 3.2.0
	 */
	protected function checkInNow(): void
	{
		// Get set check in time
		$time = ComponentHelper::getParams('com_servicedirectory')->get('check_in');

		if ($time)
		{
			// Get a db connection.
			$db = $this->getDatabase();
			// Reset query.
			$query = $db->getQuery(true);
			$query->select('*');
			$query->from($db->quoteName('#__servicedirectory_state'));
			// Only select items that are checked out.
			$query->where($db->quoteName('checked_out') . ' >= 0');
			// Query only to see if we have a rows
			$db->setQuery($query, 0, 1);
			$db->execute();
			if ($db->getNumRows())
			{
				// Get target date in the past.
				$date = Factory::getDate()->modify($time)->toSql();
				// Reset query.
				$query = $db->getQuery(true);

				// Fields to update.
				$fields = [
					$db->quoteName('checked_out_time') . ' = NULL',
					$db->quoteName('checked_out') . ' = NULL'
				];

				// Conditions for which records should be updated.
				$conditions = [
					$db->quoteName('checked_out') . ' = 0 OR ' . $db->quoteName('checked_out') . ' > 0',
					$db->quoteName('checked_out_time') . ' < ' . $db->quote($date)
				];

				// Check table.
				$query->update($db->quoteName('#__servicedirectory_state'))->set($fields)->where($conditions); 

				$db->setQuery($query);

				$db->execute();
			}
		}
	}
}
