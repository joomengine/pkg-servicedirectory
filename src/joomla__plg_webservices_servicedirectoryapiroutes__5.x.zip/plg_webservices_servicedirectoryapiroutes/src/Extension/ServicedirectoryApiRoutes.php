<?php
/**
 * @package    Service Directory
 *
 * @created    15th October, 2025
 * @author     Lemuel van der Merwe <https://github.com/joomengine/Joomla-Service-Directory>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 * A professional directory component for listing and showcasing service providers.
 */
namespace JoomService\Plugin\Webservices\ServicedirectoryApiRoutes\Extension;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Plugin\CMSPlugin;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Webservices - ServicedirectoryApiRoutes plugin.
 *
 * @package   ServicedirectoryApiRoutes
 * @since     1.0.0
 */
final class ServicedirectoryApiRoutes extends CMSPlugin
{
/**
	 * Register the JSON:API routes of com_servicedirectory.
	 *
	 * @param   \Joomla\CMS\Event\Application\BeforeApiRouteEvent  $event  The event.
	 *
	 * @return  void
	 *
	 * @since   5.0.0
	 */
	public function onBeforeApiRoute(\Joomla\CMS\Event\Application\BeforeApiRouteEvent $event): void
	{
		// Take the API router from the event.
		$router = $event->getRouter();

		// Register the JSON:API routes of com_servicedirectory.
		$defaults = ['component' => 'com_servicedirectory'];
		$getDefaults = ['public' => false, 'component' => 'com_servicedirectory'];
		$publicDefaults = ['public' => true, 'component' => 'com_servicedirectory'];

		// The routes of the tickets resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tickets', 'tickets.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tickets/:id', 'ticket.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tickets/guid/:guid', 'ticket.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/tickets', 'ticket.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/tickets/:id', 'ticket.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/tickets/guid/:guid', 'ticket.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/tickets/:id', 'ticket.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/tickets/guid/:guid', 'ticket.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the companies resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/companies', 'companies.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/companies/:id', 'company.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/companies/guid/:guid', 'company.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/companies', 'company.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/companies/:id', 'company.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/companies/guid/:guid', 'company.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/companies/:id', 'company.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/companies/guid/:guid', 'company.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the portfolios resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/portfolios', 'portfolios.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/portfolios/:id', 'portfolio.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/portfolios/guid/:guid', 'portfolio.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/portfolios', 'portfolio.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/portfolios/:id', 'portfolio.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/portfolios/guid/:guid', 'portfolio.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/portfolios/:id', 'portfolio.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/portfolios/guid/:guid', 'portfolio.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the categories resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/categories', 'categories.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/categories/:id', 'category.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/categories/guid/:guid', 'category.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/categories', 'category.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/categories/:id', 'category.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/categories/guid/:guid', 'category.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/categories/:id', 'category.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/categories/guid/:guid', 'category.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the tags resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tags', 'tags.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tags/:id', 'tag.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/tags/guid/:guid', 'tag.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/tags', 'tag.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/tags/:id', 'tag.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/tags/guid/:guid', 'tag.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/tags/:id', 'tag.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/tags/guid/:guid', 'tag.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the social_handles resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/social_handles', 'social_handles.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/social_handles/:id', 'social_handle.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/social_handles/guid/:guid', 'social_handle.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/social_handles', 'social_handle.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/social_handles/:id', 'social_handle.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/social_handles/guid/:guid', 'social_handle.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/social_handles/:id', 'social_handle.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/social_handles/guid/:guid', 'social_handle.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the areas_of_expertise resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/areas_of_expertise', 'areas_of_expertise.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/areas_of_expertise/:id', 'area_of_expertise.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/areas_of_expertise/guid/:guid', 'area_of_expertise.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/areas_of_expertise', 'area_of_expertise.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/areas_of_expertise/:id', 'area_of_expertise.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/areas_of_expertise/guid/:guid', 'area_of_expertise.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/areas_of_expertise/:id', 'area_of_expertise.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/areas_of_expertise/guid/:guid', 'area_of_expertise.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the files resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/files', 'files.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/files/:id', 'file.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/files/guid/:guid', 'file.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/files', 'file.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/files/:id', 'file.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/files/guid/:guid', 'file.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/files/:id', 'file.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/files/guid/:guid', 'file.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the addresses resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/addresses', 'addresses.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/addresses/:id', 'address.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/addresses/guid/:guid', 'address.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/addresses', 'address.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/addresses/:id', 'address.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/addresses/guid/:guid', 'address.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/addresses/:id', 'address.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/addresses/guid/:guid', 'address.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the regions resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/regions', 'regions.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/regions/:id', 'region.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/regions/guid/:guid', 'region.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/regions', 'region.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/regions/:id', 'region.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/regions/guid/:guid', 'region.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/regions/:id', 'region.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/regions/guid/:guid', 'region.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the subregions resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/subregions', 'subregions.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/subregions/:id', 'subregion.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/subregions/guid/:guid', 'subregion.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/subregions', 'subregion.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/subregions/:id', 'subregion.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/subregions/guid/:guid', 'subregion.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/subregions/:id', 'subregion.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/subregions/guid/:guid', 'subregion.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the countries resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/countries', 'countries.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/countries/:id', 'country.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/countries/guid/:guid', 'country.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/countries', 'country.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/countries/:id', 'country.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/countries/guid/:guid', 'country.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/countries/:id', 'country.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/countries/guid/:guid', 'country.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the states resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/states', 'states.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/states/:id', 'state.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/states/guid/:guid', 'state.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/states', 'state.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/states/:id', 'state.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/states/guid/:guid', 'state.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/states/:id', 'state.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/states/guid/:guid', 'state.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the cities resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/cities', 'cities.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/cities/:id', 'city.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/cities/guid/:guid', 'city.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/cities', 'city.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/cities/:id', 'city.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/cities/guid/:guid', 'city.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/cities/:id', 'city.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/cities/guid/:guid', 'city.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the timezones resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/timezones', 'timezones.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/timezones/:id', 'timezone.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/timezones/guid/:guid', 'timezone.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/timezones', 'timezone.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/timezones/:id', 'timezone.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/timezones/guid/:guid', 'timezone.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/timezones/:id', 'timezone.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/timezones/guid/:guid', 'timezone.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the platforms resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/platforms', 'platforms.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/platforms/:id', 'platform.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/platforms/guid/:guid', 'platform.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/platforms', 'platform.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/platforms/:id', 'platform.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/platforms/guid/:guid', 'platform.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/platforms/:id', 'platform.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/platforms/guid/:guid', 'platform.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the languages resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/languages', 'languages.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/languages/:id', 'language.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/languages', 'language.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/languages/:id', 'language.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/languages/:id', 'language.delete', ['id' => '(\d+)'], $defaults),
		]);

		// The routes of the address_types resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/address_types', 'address_types.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/address_types/:id', 'address_type.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/address_types/guid/:guid', 'address_type.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/address_types', 'address_type.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/address_types/:id', 'address_type.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/address_types/guid/:guid', 'address_type.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/address_types/:id', 'address_type.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/address_types/guid/:guid', 'address_type.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the file_types resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/file_types', 'file_types.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/file_types/:id', 'file_type.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/file_types/guid/:guid', 'file_type.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/file_types', 'file_type.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/file_types/:id', 'file_type.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/file_types/guid/:guid', 'file_type.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/file_types/:id', 'file_type.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/file_types/guid/:guid', 'file_type.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the company_languages resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_languages', 'company_languages.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_languages/:id', 'company_language.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_languages/guid/:guid', 'company_language.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/company_languages', 'company_language.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_languages/:id', 'company_language.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_languages/guid/:guid', 'company_language.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_languages/:id', 'company_language.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_languages/guid/:guid', 'company_language.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the company_tags resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_tags', 'company_tags.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_tags/:id', 'company_tag.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_tags/guid/:guid', 'company_tag.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/company_tags', 'company_tag.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_tags/:id', 'company_tag.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_tags/guid/:guid', 'company_tag.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_tags/:id', 'company_tag.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_tags/guid/:guid', 'company_tag.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the company_areas_of_expertise resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_areas_of_expertise', 'company_areas_of_expertise.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_areas_of_expertise/:id', 'company_area_of_expertise.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/company_areas_of_expertise/guid/:guid', 'company_area_of_expertise.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/company_areas_of_expertise', 'company_area_of_expertise.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_areas_of_expertise/:id', 'company_area_of_expertise.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/company_areas_of_expertise/guid/:guid', 'company_area_of_expertise.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_areas_of_expertise/:id', 'company_area_of_expertise.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/company_areas_of_expertise/guid/:guid', 'company_area_of_expertise.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the ticket_comments resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/ticket_comments', 'ticket_comments.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/ticket_comments/:id', 'ticket_comment.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/ticket_comments/guid/:guid', 'ticket_comment.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/ticket_comments', 'ticket_comment.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/ticket_comments/:id', 'ticket_comment.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/ticket_comments/guid/:guid', 'ticket_comment.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/ticket_comments/:id', 'ticket_comment.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/ticket_comments/guid/:guid', 'ticket_comment.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the review_company_updates resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/review_company_updates', 'review_company_updates.displayList', [], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/review_company_updates/:id', 'review_company_update.displayItem', ['id' => '(\d+)'], $getDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/review_company_updates/guid/:guid', 'review_company_update.displayItem', ['guid' => '([0-9a-fA-F-]{36})'], $getDefaults),
			new \Joomla\Router\Route(['POST'], 'v1/servicedirectory/review_company_updates', 'review_company_update.add', [], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/review_company_updates/:id', 'review_company_update.edit', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['PATCH'], 'v1/servicedirectory/review_company_updates/guid/:guid', 'review_company_update.edit', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/review_company_updates/:id', 'review_company_update.delete', ['id' => '(\d+)'], $defaults),
			new \Joomla\Router\Route(['DELETE'], 'v1/servicedirectory/review_company_updates/guid/:guid', 'review_company_update.delete', ['guid' => '([0-9a-fA-F-]{36})'], $defaults),
		]);

		// The routes of the directory resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/directory', 'directory.displayList', [], $publicDefaults),
		]);

		// The routes of the site_companies resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/site_companies', 'site_companies.displayList', [], $publicDefaults),
		]);

		// The routes of the site_category resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/site_category', 'site_category.displayList', [], $publicDefaults),
		]);

		// The routes of the listing resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/listing', 'listing.displayItem', [], $publicDefaults),
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/listing/:id', 'listing.displayItem', ['id' => '(\d+)'], $publicDefaults),
		]);

		// The routes of the site_tag resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/site_tag', 'site_tag.displayList', [], $publicDefaults),
		]);

		// The routes of the areaofexpertise resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/areaofexpertise', 'areaofexpertise.displayList', [], $publicDefaults),
		]);

		// The routes of the lang resource.
		$router->addRoutes([
			new \Joomla\Router\Route(['GET'], 'v1/servicedirectory/lang', 'lang.displayList', [], $publicDefaults),
		]);
	}
}
