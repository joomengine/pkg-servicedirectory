# Privacy - Servicedirectory (2.0.0)

The plugin to fully integrate servicedirectory with the privacy suite of Joomla.

# Build Details

+ *Company*: [Vast Development Method](https://github.com/joomengine/Joomla-Service-Directory)
+ *Author*: [Lemuel van der Merwe](mailto:joomla@vdm.io)
+ *Version*: 2.0.0
+ *Copyright*: Copyright (C) 2015 Vast Development Method. All rights reserved.
+ *License*: GNU General Public License version 2 or later; see LICENSE.txt