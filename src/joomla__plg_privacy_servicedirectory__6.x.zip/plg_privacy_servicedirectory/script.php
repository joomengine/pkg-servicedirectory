<?php
/**
 * @package    Service Directory
 *
 * @created    15th October, 2025
 * @author     Lemuel van der Merwe <https://github.com/joomengine/Joomla-Service-Directory>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 * A professional directory component for listing and showcasing service providers.
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Version;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Language\Text;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;

/**
 * Privacy - Servicedirectory script file.
 *
 * @package Servicedirectory
 */
class plgPrivacyServicedirectoryInstallerScript
{
	/**
	 * The CMS Application.
	 *
	 * @since  4.4.2
	 */
	protected $app;

	/**
	 * A list of files to be deleted
	 *
	 * @var    array
	 * @since  3.6
	 */
	protected array $deleteFiles = [];

	/**
	 * A list of folders to be deleted
	 *
	 * @var    array
	 * @since  3.6
	 */
	protected array $deleteFolders = [];

	/**
	 * Constructor
	 *
	 * @param   InstallerAdapter  $adapter  The object responsible for running this script
	 */
	public function __construct($adapter)
	{
		// get application
		$this->app = Factory::getApplication();

		if (is_file(JPATH_ROOT . '/plugins/privacy/servicedirectory/servicedirectory.php'))
		{
			$this->deleteFiles[] = '/plugins/privacy/servicedirectory/servicedirectory.php';
		}
	}

	/**
	 * Called before any type of action
	 *
	 * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
	 * @param   InstallerAdapter  $adapter  The object responsible for running this script
	 *
	 * @return  boolean  True on success
	 */
	public function preflight($route, $adapter)
	{
		// set application to local method var, just use $this->app in future [we will drop $app in J6]
		$app = $this->app;

		// the default for both install and update
		$jversion = new Version();
		if (!$jversion->isCompatible('5.0.0'))
		{
			$app->enqueueMessage('Please upgrade to at least Joomla! 5.0.0 before continuing!', 'error');
			return false;
		}

		if ('install' === $route)
		{
			// check that servicedirectory is installed
			if (!is_dir(JPATH_ADMINISTRATOR . '/components/com_servicedirectory'))
			{
				$app->enqueueMessage('JCB must first be installed from <a href="https://www.joomlacomponentbuilder.com/" target="_blank">Joomla Component Builder</a>.', 'error');
				return false;
			}
		}

		// remove old files and folders
		$this->removeFiles();

		return true;
	}

	/**
	 * Called before any type of action
	 *
	 * @param   string  $route  Which action is happening (install|uninstall|discover_install|update)
	 * @param   InstallerAdapter  $adapter  The object responsible for running this script
	 *
	 * @return  boolean  True on success
	 */
	public function postflight($route, $adapter)
	{
		// set application to local method var, just use $this->app in future [we will drop $app in J6]
		$app = $this->app;

		return true;
	}

	/**
	 * Remove the files and folders in the given array from
	 *
	 * @return  void
	 * @since   5.0.2
	 */
	protected function removeFiles()
	{
		if (!empty($this->deleteFiles))
		{
			foreach ($this->deleteFiles as $file)
			{
				if (is_file(JPATH_ROOT . $file) && !File::delete(JPATH_ROOT . $file))
				{
					echo Text::sprintf('JLIB_INSTALLER_ERROR_FILE_FOLDER', $file) . '<br>';
				}
			}
		}

		if (!empty($this->deleteFolders))
		{
			foreach ($this->deleteFolders as $folder)
			{
				if (is_dir(JPATH_ROOT . $folder) && !Folder::delete(JPATH_ROOT . $folder))
				{
					echo Text::sprintf('JLIB_INSTALLER_ERROR_FILE_FOLDER', $folder) . '<br>';
				}
			}
		}
	}
}
