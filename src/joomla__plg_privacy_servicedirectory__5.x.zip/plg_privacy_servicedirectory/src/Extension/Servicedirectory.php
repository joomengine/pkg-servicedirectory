<?php
/**
 * @package    Service Directory
 *
 * @created    4th October, 2025
 * @author     Lemuel van der Merwe <https://github.com/joomengine/Joomla-Service-Directory>
 * @copyright  Copyright (C) 2015 Vast Development Method. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 *
 * A professional directory component for listing and showcasing service providers.
 */
namespace JoomService\Plugin\Privacy\Servicedirectory\Extension;

use Joomla\Utilities\ArrayHelper;
use Joomla\Component\Privacy\Administrator\Plugin\PrivacyPlugin;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Component\Privacy\Administrator\Table\RequestTable;
use Joomla\CMS\User\User;
use Joomla\Component\Privacy\Administrator\Removal\Status;
use JoomService\Component\Servicedirectory\Administrator\Helper\ServicedirectoryHelper;
use Joomla\Component\Privacy\Administrator\Export\Domain;

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Privacy - Servicedirectory plugin.
 *
 * @package   Servicedirectory
 * @since     2.0.0
 */
final class Servicedirectory extends PrivacyPlugin
{
	use DatabaseAwareTrait;

	/**
	 * Affects constructor behavior. If true, language files will be loaded automatically.
	 *
	 * @var    boolean
	 * @since  1.0
	 */
	protected  $autoloadLanguage = true;

	/**
	 * Performs validation to determine if the data associated with a remove information request can be processed
	 *
	 * @param   RequestTable  $request  The request record being processed
	 * @param   User                $user     The user account associated with this request if available
	 *
	 * @return  Status
	 *
	 * @since   1.0
	 */
	public function onPrivacyCanRemoveData(RequestTable $request, User $user = null)
	{
		$status = new Status();

		// This plugin only processes data for registered user accounts
		if (!$user)
		{
			return $status;
		}

		// check if the helper method is set in the component
		if (method_exists(ServicedirectoryHelper::class, 'onPrivacyCanRemoveData'))
		{
			ServicedirectoryHelper::onPrivacyCanRemoveData($this, $status, $request, $user);
		}

		return $status;
	}

	/**
	 * Processes an export request for Joomla core user data
	 *
	 * @param   RequestTable  $request  The request record being processed
	 * @param   User                $user     The user account associated with this request if available
	 *
	 * @return  Domain[]
	 *
	 * @since   1.0
	 */
	public function onPrivacyExportRequest(RequestTable $request, User $user = null)
	{
		$domains = array();

		// This plugin only processes data for registered user accounts
		if (!$user)
		{
			return $domains;
		}

		// check if the helper method is set in the component
		if (method_exists(ServicedirectoryHelper::class, 'onPrivacyExportRequest'))
		{
			ServicedirectoryHelper::onPrivacyExportRequest($this, $domains, $request, $user);
		}

		return $domains;
	}

	/**
	 * Removes the data associated with a remove information request
	 *
	 * @param   RequestTable  $request  The request record being processed
	 * @param   User                $user     The user account associated with this request if available
	 *
	 * @return  void
	 *
	 * @since   1.0
	 */
	public function onPrivacyRemoveData(RequestTable $request, User $user = null)
	{
		// This plugin only processes data for registered user accounts
		if (!$user)
		{
			return;
		}

		// check if the helper method is set in the component
		if (method_exists(ServicedirectoryHelper::class, 'onPrivacyRemoveData'))
		{
			ServicedirectoryHelper::onPrivacyRemoveData($this, $request, $user);
		}
	}
}
